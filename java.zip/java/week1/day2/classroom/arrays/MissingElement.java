package week1.day2.classroom.arrays;

import java.util.Arrays;

public class MissingElement {

	
	public static void main(String[] args) {

		// Here is the input
		int[] data = {3,2,4,6,7,8};

		/*
		 Pseudo Code:
		 1) Arrange the array in ascending order
		 2) Traverse through each array item
		 3) Compare consecutive items -> 
		 		the next one should be = previous one + 1
		 4) If the following one is not +1 -> Print as missing
		 */
		
		
		Arrays.sort(data);
		int len=data.length;
		for(int i=1;i<=len;i++)
		{
			int first=data[i];//2
			int sec=data[i+1];//3
			if(sec!=first+1)
			{
				System.out.println(sec-1);
			}
		}
		//System.out.println(data[(len-1)]);
		
			
		// Print the second largest number	
		System.out.println("Second largest number " +data[len-2]);
		
	}

}
