package week1.assignments.optional;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		       //Declare a String 
				String text1 = "stop";
				//Declare another String
				String text2 = "pots";
				
				//build logic to check the given words are anagram or not
				
				/*
				 * Pseudo Code
				 * a) Check length of the strings are same then
				 * b) Convert both Strings in to characters
				 * c) Sort Both the arrays
				 * d) Check both the arrays has same value
				 * 
				 */

				int len1=text1.length();
				int len2=text2.length();
				
				if(len1==len2)
				{
					
				char[] ch1=text1.toCharArray();
				char[] ch2=text2.toCharArray();
				
				Arrays.sort(ch1);
				System.out.println(ch1);
				Arrays.sort(ch2);
				System.out.println(ch2);
				for(int i=0;i<=len1-1;i++)
				{
					if(ch1[i]==ch2[i])
					{
						System.out.println("Same characters: "+ch1[i] +ch2[i]);
					}
				}
				
				}
				else
				{
					System.out.println("Not in same length");
				}
				
				
	}

}
