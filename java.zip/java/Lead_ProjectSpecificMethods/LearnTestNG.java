package Lead_ProjectSpecificMethods;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

@Test
public class LearnTestNG extends ProjectSpecificMethod {

	@Test(priority='3', enabled=true)
	public void createLead1()
	{
		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		// Click on Create Lead button
		driver.findElementByLinkText("Create Lead").click();

		// Enter Company Name
		driver.findElementById("createLeadForm_companyName").sendKeys("HCL");

		// Enter First Name
		driver.findElementById("createLeadForm_firstName").sendKeys("Sakthi");

		// Enter Last Name
		driver.findElementById("createLeadForm_lastName").sendKeys("M");

		//Phone number
		driver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys("9876543210");

		//Email address
		driver.findElementById("createLeadForm_primaryEmail").sendKeys("xyz@gmail.com");

		// Click on Create Lead (Submit) button
		driver.findElementByClassName("smallSubmit").click();

		// Verify the Lead is created by checking the Company or First Name
		String str=driver.findElementById("viewLead_firstName_sp").getText();

		//Verify Currency name
		String str1=driver.findElementById("viewLead_currencyUomId_sp").getText();
		if(str.contains("Sakthi")&&str1.contains("INR - Indian Rupee"))
		{
			System.out.println("Name verified");
			System.out.println("Currency selection verified");
		}
	}

	@Test(priority='2', enabled=true, dependsOnMethods = {"createLead1"})
	public void editLead1() throws InterruptedException
	{
		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		//Find leads
		driver.findElementByLinkText("Find Leads").click();

		//Select First name
		driver.findElementByXPath("(//div//input[@name='firstName'])[3]").sendKeys("Sakthi");
		driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();

		Thread.sleep(2000);

		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();

		Thread.sleep(2000);
		driver.findElementById("center-content-column").isDisplayed();
		driver.findElementByLinkText("Edit").click();
		WebElement compName=driver.findElementById("updateLeadForm_companyName");
		compName.clear();
		compName.sendKeys("HCL Updated");

		driver.findElementByXPath("//*[@class='smallSubmit' and @value='Update']").click();

		String str=driver.findElementById("viewLead_companyName_sp").getText();
		if(str.equals("HCL Updated (10425)"))
		{
			System.out.println("Company Name updated");
		}
		else
		{
			System.out.println("Company name not updated");
		}	


	}

	@Test(priority='1')
	public void duplicateLead() throws InterruptedException
	{
		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		//Find leads
		driver.findElementByLinkText("Find Leads").click();

		//Select Email
		driver.findElementByXPath("(//span[contains(@class,'x-tab-strip-text ')])[3]").click();
		driver.findElementByXPath("//input[contains(@name,'emailAddress')]").sendKeys("xyz@gmail.com");
		driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();

		Thread.sleep(3000);

		//Select first result
		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();

		Thread.sleep(2000);
		driver.findElementById("center-content-column").isDisplayed();

		//Click Duplicate lead
		driver.findElementByLinkText("Duplicate Lead").click();
		String leadTitle=driver.findElementById("sectionHeaderTitle_leads").getText();
		System.out.println(leadTitle);

		driver.findElementByName("submitButton").click();

		String str=driver.findElementById("viewLead_firstName_sp").getText();
		if(str.equals("Sakthi"))
		{
			System.out.println("Same name remains");
		}
		else
		{
			System.out.println("Name updated");
		}
	}

}
