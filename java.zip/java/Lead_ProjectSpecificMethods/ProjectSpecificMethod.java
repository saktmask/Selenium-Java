package Lead_ProjectSpecificMethods;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

public class ProjectSpecificMethod {

	public ChromeDriver driver;
	public String excelFileName;

	@BeforeMethod
	@Parameters({"url","uname","password"})
	public void login(String url, String userName, String passWord)
	{
		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");

		// Initiate the ChromeBroswer
		driver=new ChromeDriver();

		// Maximize the browser
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//URL
		driver.get(url);

		// Enter the UserName
		driver.findElementById("username").sendKeys(userName);

		// Enter the Password
		driver.findElementById("password").sendKeys(passWord);

		// Click on Login Button
		driver.findElementByClassName("decorativeSubmit").click();

		// Click on crm/sfa button
		driver.findElementByLinkText("CRM/SFA").click();

	}

	@AfterMethod
	public void logout()
	{
		driver.close();
	}
	 
	
	//Static way of passing inputs//
	/*@DataProvider
	public String[][] getData()

	{
		String[][] data=new String[2][3];

		data[0][0]="Sakthi";
		data[0][1]="M";
		data[0][2]="HCL";

		data[1][0]="Sathish";
		data[1][1]="M";
		data[1][2]="HCL";

		return data;

	}*/

	@DataProvider
	public String[][] getData() throws IOException
	{
		ReadExcel rd=new ReadExcel();
		return rd.readExcel(excelFileName);

	}

}
