package Lead_ProjectSpecificMethods;

import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public String[][] readExcel(String fileName) throws IOException
	{
		//Access excel
		XSSFWorkbook wbook=new XSSFWorkbook("./data/"+fileName+".xlsx");

		//Get first sheet
		XSSFSheet wsheet = wbook.getSheetAt(0);

		//Get number of rows available
		int rowCount = wsheet.getLastRowNum();

		//Get number of columns available for zero th row
		short colCount = wsheet.getRow(0).getLastCellNum();

		String[][] data=new String[rowCount][colCount];

		//Loop through rows and columns
		for (int i = 1; i <=rowCount; i++) {

			XSSFRow row = wsheet.getRow(i);

			for (int j = 0; j <colCount ; j++) {

				XSSFCell cell = row.getCell(j);
				String value=cell.getStringCellValue();
				data[i-1][j]=value;
			}
		}
		wbook.close();
		return data;

	}

}