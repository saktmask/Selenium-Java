package week3.assignment;

public interface Hardware {

	public String hardwareResources();
}
