package week3.assignment;

public abstract class Bike implements Vehicle {

	public String speed()
	{
	return "Max speed";	
	}
	
}
