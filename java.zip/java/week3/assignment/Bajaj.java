package week3.assignment;

public class Bajaj extends Bike{

	public static void main(String[] args) {
		Bike b=new Bajaj();
		System.out.println(b.speed());
		System.out.println(b.cost());
	}

	@Override
	public Integer cost() {
		return 1;
	}

}
