package week3.assignment;

public interface Vehicle {
	
	public String speed();
	public Integer cost();

}
