package week3.assignment;

public class Desktop implements Hardware, Software {

	
	@Override
	public String softwareResources() {
		
		return "Software Resources";
	}

	@Override
	public String hardwareResources() {
		
		return "Hardware Resources";
	}
	
	public String desktopModel()
	{
		return "Desktop Model";
	}

}
