package week3.assignment;

public interface Software {

	public String softwareResources();
}
