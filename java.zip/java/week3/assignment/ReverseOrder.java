package week3.assignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReverseOrder {

	public static void main(String[] args) {
		
		String[] input= {"CTS","Aspire Systems","HCL"};
		List<String> li=new ArrayList<>();
		for (String string : input) {
			li.add(string);	
		}
		System.out.println("Before sort: "+li);
		Collections.sort(li);
		Collections.reverse(li);
		System.out.println("After sort: "+li);

	}

}
