package week3.assignment;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DistinctCharacters {

	public static void main(String[] args) {
		String input="Amazon India Private Limited";
		input=input.replace(" ", "");
		char[] ch=input.toCharArray();
		
		Map<Character,Integer> m=new LinkedHashMap<>();
		for (char c : ch) {
			if(m.containsKey(c))
			{
				Integer i=m.get(c)+1;
				m.put(c, i);	
			}
			else
			{
				m.put(c, 1);
			}
			
		}
		
		for (Entry<Character, Integer> c : m.entrySet()) {
			System.out.print(c.getKey());
			
		}

	}

}
