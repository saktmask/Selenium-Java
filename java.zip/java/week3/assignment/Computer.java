package week3.assignment;

public class Computer extends Desktop {

	public static void main(String[] args) {
		
		Computer d=new Computer();
		System.out.println(d.hardwareResources());
		System.out.println(d.softwareResources());
		System.out.println(d.desktopModel());
	}

}
