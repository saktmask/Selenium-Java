package week3.day2.classroom;

import java.util.LinkedList;
import java.util.List;

public class RepeatingCharacters {

	public static void main(String[] args) {
		String input = "PayPal India";
		input=input.replace(" ", "");
		char[] ch=input.toCharArray();
		
		List<Character> m=new LinkedList<>();
		
		for (char c : ch) {
			if(m.contains(c))
			{
				//m.remove(c);
				System.out.println(c);
				break;				
			}
			else
			{
				m.add(c);
			}
			
		}
		//System.out.println(m);

	}

}
