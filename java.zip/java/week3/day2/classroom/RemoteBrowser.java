package week3.day2.classroom;

public class RemoteBrowser implements Browser {

		
	public void locateElement(String locator) {

		System.out.println("Locator");
	}


	public String getTitle() {

		System.out.println("Get Title");
		return null;
	}


	public void close() {

		System.out.println("Close");
	}

}
