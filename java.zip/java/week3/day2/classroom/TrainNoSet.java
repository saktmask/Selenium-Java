package week3.day2.classroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TrainNoSet {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");
		ChromeDriver driver = new ChromeDriver();
		//Loading a url
		driver.get("https://erail.in/");
		driver.manage().window().maximize();
		WebElement elesource = driver.findElementById("txtStationFrom");
		elesource.clear();
		elesource.sendKeys("MAS",Keys.TAB);
		WebElement eledestiny = driver.findElementById("txtStationTo");
		eledestiny.clear();
		eledestiny.sendKeys("SBC",Keys.TAB);
		Thread.sleep(3000);
		driver.findElementById("chkSelectDateOnly").click();
		WebElement eletable = driver
				.findElementByXPath("//table[@class='DataTable TrainList TrainListHeader']");
		List<WebElement> row = eletable.findElements(By.tagName("tr"));

		Set<String> se=new TreeSet<String>();
		List<String> li=new ArrayList<String>();

		for (int i = 0; i < row.size(); i++) {
			List<WebElement> coldata = row.get(i).findElements(By.tagName("td"));
			//System.out.println(coldata.get(1).getText());

			li.add(coldata.get(0).getText());
			se.add(coldata.get(0).getText());
		}

		int len1=se.size();
		int len2=li.size();

		if(len1!=len2) {
			System.out.println("Duplicates removed in Set");
		}
		else
		{
			System.out.println("Duplicates included");
		}
		//System.out.println(len1);
		//System.out.println(len2);

	}

}
