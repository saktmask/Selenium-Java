package week3.day2.classroom;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class LearnMap {

	public static void main(String[] args) {
		String text="SakthiManoharan";
		char[] ch=text.toCharArray();
		Map<Character,Integer> obj=new HashMap<>();
		int len=ch.length;
		for(int i=0;i<len;i++)
		{
			if(obj.containsKey(ch[i]))
			{
				obj.put(ch[i], obj.get(ch[i])+1);
				
			}
			else
			{
				obj.put(ch[i], 1);
			}
			
		}
		for (Entry<Character,Integer> c : obj.entrySet()) {
			System.out.println(c.getKey()+"->"+c.getValue());
			
		}

	}

}
