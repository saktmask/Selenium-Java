package week3.day2.classroom;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class DuplicateCharacters {

	public static void main(String[] args) {
		
		String input = "Infosys Limited";
		input=input.replace(" ", "");
		char[] ch=input.toCharArray();
		
		Map<Character, Integer> m=new LinkedHashMap<>();
		
		for (char c : ch) {
			if(m.containsKey(c))
			{
				Integer i=m.get(c)+1;
				m.put(c, i);
			}
			else
			{
				m.put(c, 1);
			}
			
		}
		
		for (Entry<Character, Integer> c : m.entrySet()) {
			if(c.getValue()>1)
			{
				System.out.print(c.getKey());
			}
			
		}

	}

}
