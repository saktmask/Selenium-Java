package week3.day2.classroom;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class RemoveDuplicateCharacters {

	public static void main(String[] args) {
		
		String input = "PayPal India";
		input=input.replace(" ", "");
		char[] ch=input.toCharArray();
		
		Set<Character> m=new LinkedHashSet<>();
		
		for (char c : ch) {
		
				m.add(c);
			
		}
		System.out.println(m);
		
		/*
		for (char c : ch) {
			if(m.contains(c))
			{
					//m.remove(m.indexOf(c));
					m.remove(c);			
			}
			else
			{
				m.add(c);
			}
			
		}
		System.out.println(m);*/
		/*
		
		Map<Character, Integer> m= new LinkedHashMap<>();
		for (char c : ch) {
			if(m.containsKey(c))
			{
				int value=m.get(c)+1;
				m.put(c, value);
			}
			else
			{
				m.put(c, 1);
			}
			
		}
		System.out.println(m);
		int len=m.size();
		//System.out.println(len);
		for(int i=0;i<len;i++)
		{
			System.out.println(m.get(i));
		}
		
		/*for (Entry<Character, Integer> eachEntry : m.entrySet()) {
			
			if(m.get(eachEntry)>1)
			{
				
				//m.remove(eachEntry);
			}
			//System.out.println(m);
		}*/
		
		

	}

}
