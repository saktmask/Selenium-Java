package week3.day2.classroom;

public class Snippet {
	public static void main(String[] args) {
		System.out.println("Locator");
	}
}

