package week3.day1.classroom;

public class Redmi extends Mobile {
	public String model()
	{
		return "REDMI";
	}
	
	public String price()
	{
		return "10000";
	}

	public void makeCall()
	{
		System.out.println("Make Whatsapp call");
	}
	
	public String sendText()
	{
		return "Specify mobile no";
	}
	
	public String sendText(String mobileNo)
	{
		
		return "Message sent";		
	}
}
