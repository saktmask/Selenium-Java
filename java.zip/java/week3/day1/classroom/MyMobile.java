package week3.day1.classroom;

public class MyMobile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Redmi rm=new Redmi();
		Samsung sm=new Samsung();
		rm.memory();
		rm.ram();
		sm.memory();
		sm.ram();
		System.out.println(rm.price());
		System.out.println(rm.model());
		rm.makeCall();
		System.out.println(rm.sendText());
		System.out.println(rm.sendText("9876543210"));
		sm.makeCall();
		
	}

}
