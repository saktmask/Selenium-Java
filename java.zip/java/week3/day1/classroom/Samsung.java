package week3.day1.classroom;

public class Samsung extends Mobile {

	public String model()
	{
		return "Samsung";
	}
	
	public String price()
	{
		return "12000";
	}
	
}
