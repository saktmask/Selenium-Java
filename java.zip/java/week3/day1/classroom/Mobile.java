package week3.day1.classroom;

public class Mobile {
	public void ram()
	{
		System.out.println("RAM: 4GB");
	}
	public void memory()
	{
		System.out.println("Memory: 64GB");
	}
	public void makeCall()
	{
		System.out.println("Make normal call");
	}
	

}
