package week2.day1.classroom;

import org.openqa.selenium.chrome.ChromeDriver;

public class CreateLead {

	public static void main(String[] args) {

		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");
		
		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();
		
		// Maximize the browser
		driver.manage().window().maximize();
		
		//URL
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		// Enter the UserName
		driver.findElementById("username").sendKeys("DemoSalesManager");
		
		// Enter the Password
		driver.findElementById("password").sendKeys("crmsfa");
		
		// Click on Login Button
		driver.findElementByClassName("decorativeSubmit").click();
		
		// Click on crm/sfa button
		driver.findElementByLinkText("CRM/SFA").click();
		
		// Click on Leads
		driver.findElementByLinkText("Leads").click();
		
		// Click on Create Lead button
		driver.findElementByLinkText("Create Lead").click();
		
		// Enter Company Name
		driver.findElementById("createLeadForm_companyName").sendKeys("HCL");
		
		// Enter First Name
		driver.findElementById("createLeadForm_firstName").sendKeys("Sakthi");
		
		// Enter Last Name
		driver.findElementById("createLeadForm_lastName").sendKeys("M");
		
		// Click on Create Lead (Submit) button
		driver.findElementByClassName("smallSubmit").click();
		
		// Verify the Lead is created by checking the Company or First Name
		System.out.println(driver.findElementById("viewLead_firstName_sp").getText());
	}

}
