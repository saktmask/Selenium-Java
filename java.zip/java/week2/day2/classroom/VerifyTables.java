package week2.day2.classroom;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyTables {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");
		
		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();
		
		// Maximize the browser
		driver.manage().window().maximize();
		
		//URL
		driver.get("http://erail.in/");
		
		driver.findElementById("chkSelectDateOnly").click();
		
		WebElement ele_src=driver.findElementById("txtStationFrom");
		ele_src.clear();
		ele_src.sendKeys("MAS",Keys.TAB);
		WebElement ele_des=driver.findElementById("txtStationTo");
		ele_des.clear();
		ele_des.sendKeys("SBC",Keys.TAB);
		
		Thread.sleep(3000);
		driver.findElementById("buttonFromTo").click();
		
		WebElement ele=driver.findElementByXPath("//table[@class='DataTable TrainList TrainListHeader']");
		List<WebElement> l_ele=ele.findElements(By.tagName("tr"));
		int size=l_ele.size();
				
		for(int i=0;i<size;i++)
		{
			List<WebElement> l_ele1=l_ele.get(i).findElements(By.tagName("td"));
			System.out.println(l_ele1.get(1).getText());
			System.out.print(l_ele1.get(0).getText());
		}

			driver.close();
	}

}
