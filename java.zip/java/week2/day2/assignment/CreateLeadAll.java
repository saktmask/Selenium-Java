package week2.day2.assignment;

import java.util.*;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CreateLeadAll {

	public static void main(String[] args) {

		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");
		
		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();
		
		// Maximize the browser
		driver.manage().window().maximize();
		
		//URL
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		// Enter the UserName
		driver.findElementById("username").sendKeys("DemoSalesManager");
		
		// Enter the Password
		driver.findElementById("password").sendKeys("crmsfa");
		
		// Click on Login Button
		driver.findElementByClassName("decorativeSubmit").click();
		
		// Click on crm/sfa button
		driver.findElementByLinkText("CRM/SFA").click();
		
		// Click on Leads
		driver.findElementByLinkText("Leads").click();
		
		// Click on Create Lead button
		driver.findElementByLinkText("Create Lead").click();
		
		// Enter Company Name
		driver.findElementById("createLeadForm_companyName").sendKeys("HCL");
		
		// Enter First Name
		driver.findElementById("createLeadForm_firstName").sendKeys("Sakthi");
		
		// Enter Last Name
		driver.findElementById("createLeadForm_lastName").sendKeys("M");
		
		// Select 'Source' as 'Other' (Handling DropDown)
		Select dd_Source= new Select(driver.findElementById("createLeadForm_dataSourceId"));
		dd_Source.selectByVisibleText("Other");
		
		//Select 'Marketting campaign' as Last before
		Select dd_Market=new Select(driver.findElementById("createLeadForm_marketingCampaignId"));
		List<WebElement> l_Market=dd_Market.getOptions();
		int len1=l_Market.size();
		dd_Market.selectByIndex(len1-2);
		
		//Enter Local FirstName
		driver.findElementById("createLeadForm_firstNameLocal").sendKeys("Mask");
		
		//Enter Local LastNAme
		driver.findElementById("createLeadForm_lastNameLocal").sendKeys("Last");
		
		//Enter Personal Title
		driver.findElementById("createLeadForm_personalTitle").sendKeys("Mr");
				
		// Select 'Preferred Currency' as 'INR'
		Select dd_Currency= new Select(driver.findElementById("createLeadForm_currencyUomId"));
		dd_Currency.selectByValue("INR");
	
		// Select 'Industry' as 'Computer-Hardware'
		Select dd_Industry=new Select(driver.findElementById("createLeadForm_industryEnumId"));
		dd_Industry.selectByIndex(2);
		
		// Select 'Ownership' as Last
		Select dd_Owner=new Select(driver.findElementById("createLeadForm_ownershipEnumId"));
		List<WebElement> l_Options=dd_Owner.getOptions();
		int len=l_Options.size();
		dd_Owner.selectByIndex(len-1);
		
		
		
		// Click on Create Lead (Submit) button
		driver.findElementByClassName("smallSubmit").click();
				
		// Verify the Lead is created by checking the Company or First Name
		String str=driver.findElementById("viewLead_firstName_sp").getText();
		
		//Verify Currency name
		String str1=driver.findElementById("viewLead_currencyUomId_sp").getText();
		if(str.contains("Sakthi")&&str1.contains("INR - Indian Rupee"))
		{
			System.out.println("Name verified");
			System.out.println("Currency selection verified");
			driver.close();
		}
		
	
	}

}
