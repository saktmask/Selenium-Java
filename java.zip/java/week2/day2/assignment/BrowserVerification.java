package week2.day2.assignment;

import java.util.List;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class BrowserVerification {
	
	public static void main(String[] args) throws InterruptedException {
		// Set the property for ChromeDriver
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");
				
				// Initiate the ChromeBroswer
				ChromeDriver driver=new ChromeDriver();
				
				// Maximize the browser
				driver.manage().window().maximize();
				
				//URL
				driver.get("http://leafground.com/");
				
				//Select Button link
				/*driver.findElementByLinkText("Button").click();
				String str=driver.getTitle();
				if(str.equals("TestLeaf - Interact with Buttons"))
				{
				System.out.println(str);
				System.out.println(driver.findElementById("position").getLocation());
				System.out.println(driver.findElementById("color").getCssValue("background-color"));
				System.out.println(driver.findElementById("size").getSize());
				driver.findElementById("home").click();
				//driver.close();
				}
				else
				{
					System.out.println("Incorrect page loaded");
					//driver.close();
				}*/
				
				//Select Link pages
				/*driver.findElementByLinkText("HyperLink").click();
				String str1=driver.getCurrentUrl();
				if(str1.equalsIgnoreCase("http://leafground.com/pages/Link.html"))
				{
				System.out.println(str1);
				System.out.println(driver.findElementByLinkText("Find where am supposed to go without clicking me?").getAttribute("href"));
				System.out.println(driver.findElementByLinkText("Verify am I broken?").getText());
				System.out.println(driver.findElementByLinkText("Go to Home Page").getCssValue("color"));
				System.out.println(driver.findElementByLinkText("Go to Home Page").isDisplayed());
				System.out.println(driver.findElementByLinkText("How many links are available in this page?").getTagName());
				driver.findElementByLinkText("Go to Home Page").click();
				//driver.close();
				}
				else
				{
					System.out.println("Incorrect page loaded");
					//driver.close();
				}*/
				
				//Select dropdown
				driver.findElementByLinkText("Drop down").click();
				String str2=driver.getTitle();
				
				System.out.println(str2);
				
				//System.out.println(driver.findElementById("dropdown1").isEnabled());
				Select dd=new Select(driver.findElementById("dropdown1"));
				dd.selectByValue("1");
				
				Select dd1=new Select(driver.findElementByName("dropdown2"));
				dd1.selectByVisibleText("Appium");
				System.out.println(driver.findElementById("dropdown2").getText());
				
				Select dd2=new Select(driver.findElementById("dropdown3"));
				dd2.selectByIndex(3);
				
				Select dd3=new Select(driver.findElementByClassName("dropdown"));
				List<WebElement> ele=dd3.getOptions();
				int len=ele.size();
				dd3.selectByIndex(len-1);
				
	}
}
