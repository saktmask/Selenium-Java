package week2.day2.assignment;

import org.openqa.selenium.chrome.ChromeDriver;

public class DuplicateLead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");
		
		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();
		
		// Maximize the browser
		driver.manage().window().maximize();
		
		//URL
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		// Enter the UserName
		driver.findElementById("username").sendKeys("DemoSalesManager");
		
		// Enter the Password
		driver.findElementById("password").sendKeys("crmsfa");
		
		// Click on Login Button
		driver.findElementByClassName("decorativeSubmit").click();
		
		// Click on crm/sfa button
		driver.findElementByLinkText("CRM/SFA").click();
		
		// Click on Leads
		driver.findElementByLinkText("Leads").click();
	
		//Find leads
		driver.findElementByLinkText("Find Leads").click();
		
		//Select Email
		driver.findElementByLinkText("Email").click();
		driver.findElementByName("emailAddress").sendKeys("xyz@gmail.com");
		driver.findElementByXPath("(//*[text()='Find Leads'])[3])").click();
	}

}
