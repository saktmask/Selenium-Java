package week2.assignment;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DeleteLead {

	public static void main(String[] args) throws InterruptedException {
	
		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");
		
		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();
		
		// Maximize the browser
		driver.manage().window().maximize();
		
		//URL
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		// Enter the UserName
		driver.findElementById("username").sendKeys("DemoSalesManager");
		
		// Enter the Password
		driver.findElementById("password").sendKeys("crmsfa");
		
		// Click on Login Button
		driver.findElementByClassName("decorativeSubmit").click();
		Thread.sleep(2000);
		
		// Click on crm/sfa button
		driver.findElementByLinkText("CRM/SFA").click();
		
		// Click on Leads
		driver.findElementByLinkText("Leads").click();
	
		//Find leads
		driver.findElementByLinkText("Find Leads").click();
		Thread.sleep(2000);
		
		driver.findElementByXPath("//*[@class='x-tab-strip-text ' and text()='Phone']").click();
		Thread.sleep(2000);
		
		WebElement phoneCode=driver.findElementByXPath("//*[@name='phoneCountryCode']");
		phoneCode.clear();
		phoneCode.sendKeys("91");
		driver.findElementByName("phoneNumber").sendKeys("9876543210");
		
		driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();
		
		Thread.sleep(2000);
		WebElement leadID=driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]");
		String strLead=leadID.getText();
		leadID.click();
		
		Thread.sleep(2000);
		driver.findElementById("center-content-column").isDisplayed();
		
		driver.findElementByClassName("subMenuButtonDangerous").click();
		
		//Find leads
		driver.findElementByLinkText("Find Leads").click();
		Thread.sleep(2000);
		
		driver.findElementByXPath("//*[@name='id']").sendKeys(strLead);
		driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();
		Thread.sleep(3000);
		WebElement recordInfo=driver.findElementByXPath("//div[@class='x-paging-info']");
		String result=recordInfo.getText();
		
		if(result.equals("No records to display"))
		{
			System.out.println("Records deleted");
			driver.close();
		}
		else
		{
			System.out.println("No records deleted");
		}
	}

}
