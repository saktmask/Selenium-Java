package week2.assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Flipkart {

	public static void main(String[] args) throws InterruptedException {
		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");

		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();

		// Maximize the browser
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//URL
		driver.get("https://www.flipkart.com/");
		Thread.sleep(3000);
		
		driver.findElementByXPath("//button[contains(@class,'_2AkmmA _29YdH8')]").click();
		
		Actions a = new Actions(driver);
		WebElement electronics=driver.findElementByXPath("//span[text()='Electronics']");
		WebElement mi = driver.findElementByXPath("(//a[text()='Mi'])[1]");
		a.moveToElement(electronics);
		//Thread.sleep(2000);
		
		a.click(mi).perform();
		System.out.println(driver.getTitle());

	}

}
