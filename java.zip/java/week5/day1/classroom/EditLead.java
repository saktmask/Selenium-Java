package week5.day1.classroom;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Lead_ProjectSpecificMethods.ProjectSpecificMethod;

public class EditLead extends ProjectSpecificMethod {

	@Test
	public void editLead() throws InterruptedException {	

		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		//Find leads
		driver.findElementByLinkText("Find Leads").click();

		//Select Firstname
		driver.findElementByXPath("(//div//input[@name='firstName'])[3]").sendKeys("Sakthi");
		driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();

		Thread.sleep(2000);

		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();

		Thread.sleep(2000);
		driver.findElementById("center-content-column").isDisplayed();
		driver.findElementByLinkText("Edit").click();
		WebElement compName=driver.findElementById("updateLeadForm_companyName");
		compName.clear();
		compName.sendKeys("HCL Updated");

		driver.findElementByXPath("//*[@class='smallSubmit' and @value='Update']").click();

		String str=driver.findElementById("viewLead_companyName_sp").getText();
		if(str.equals("HCL Updated (10425)"))
		{
			System.out.println("Company Name updated");
			//driver.close();
		}
		else
		{
			System.out.println("Company name not updated");
			//driver.close();
		}	

	}

}
