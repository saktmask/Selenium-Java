package week5.day1.classroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import Lead_ProjectSpecificMethods.ProjectSpecificMethod;

public class MergeLead extends ProjectSpecificMethod {

	@Test
	public void mergeLead() throws InterruptedException {
		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		//Merge Leads
		driver.findElementByLinkText("Merge Leads").click();

		//Click Image of From Lead
		driver.findElementByXPath("(//img[contains(@src,'/images/fieldlookup.gif')])[1]").click();

		//Switch to new window
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> listHandle=new ArrayList<>(windowHandles);
		String str=listHandle.get(1);
		driver.switchTo().window(str);

		//Find Lead ID
		driver.findElementByName("id").sendKeys("10351");

		//Find leads
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();

		Thread.sleep(2000);

		//Select first result
		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();

		//Close the current window
		//driver.close();

		//Switch the control to parent window
		str=listHandle.get(0);
		driver.switchTo().window(str);

		Thread.sleep(2000);

		//Click Image of To Lead
		driver.findElementByXPath("(//img[contains(@src,'/images/fieldlookup.gif')])[2]").click();

		//Switch to new window
		Set<String> windowHandles1 = driver.getWindowHandles();
		List<String> listHandle1=new ArrayList<>(windowHandles1);
		String str1=listHandle1.get(1);
		driver.switchTo().window(str1);

		//Find Lead ID
		driver.findElementByName("id").sendKeys("10414");

		//Find leads
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();

		Thread.sleep(2000);

		//Select first result
		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();

		//Close the current window
		//driver.close();

		//Switch the control to parent window
		str1=listHandle1.get(0);
		driver.switchTo().window(str1);

		//Click on Merge button
		driver.findElementByXPath("//a[contains(@class,'buttonDangerous')]").click();
		Thread.sleep(2000);

		//Alert
		Alert a =driver.switchTo().alert();
		a.accept();

		//Find leads
		driver.findElementByLinkText("Find Leads").click();

		//Find Lead ID
		driver.findElementByName("id").sendKeys("10351");

		//Find leads
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();

		Thread.sleep(3000);
		WebElement recordInfo=driver.findElementByXPath("//div[@class='x-paging-info']");
		String result=recordInfo.getText();

		if(result.equals("No records to display"))
		{
			System.out.println("Records deleted");
			//driver.close();
		}
		else
		{
			System.out.println("No records deleted");
		}

	}

}
