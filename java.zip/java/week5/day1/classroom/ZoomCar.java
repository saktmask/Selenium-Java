package week5.day1.classroom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZoomCar {
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");
		ChromeDriver driver = new ChromeDriver();

		//Open the Amazon URL
		driver.get("https://www.zoomcar.com/chennai/search/query?lat=12.9416037&lng=80.2362096&starts=2019-12-23%2020%3A00&ends=2019-12-24%2002%3A00&type=zoom_later&bracket=with_fuel");
		driver.manage().window().maximize();
		
		List<CarPrice> ls = new ArrayList<CarPrice>();
		List<WebElement> carName = driver.findElementsByTagName("h3");
		List<WebElement> carPrice = driver.findElementsByClassName("price");
		List<WebElement> bookCar = driver.findElementsByClassName("book-car");
		
		for (int i = 0; i < carName.size(); i++) {
			ls.add(new CarPrice(carName.get(i), Integer.parseInt(carPrice.get(i).getText().replaceAll("\\D", "")), bookCar.get(i)));

		}
		
		Collections.sort(ls);
		System.out.println(ls);
		CarPrice carPrice2 = ls.get(ls.size()-1);
		System.out.println(carPrice2.ele.getText());
		carPrice2.book.click();
		Thread.sleep(5000);
		driver.quit();
	}

}
class CarPrice implements Comparable<CarPrice>{
	WebElement ele;
	WebElement book;

	public CarPrice(WebElement ele, int price, WebElement book) {
		this.ele = ele;
		this.price = price;
		this.book = book;
	}

	private int price;

	@Override
	public String toString() {
		return "CarPrice [ele=" + ele + ", price=" + price + "]";
	}

	public int compareTo(CarPrice o) {

		if(this.price < o.price)
		{
			return -1;
		}
		else return 1;
	}
}