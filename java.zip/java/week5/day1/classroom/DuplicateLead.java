package week5.day1.classroom;


import org.testng.annotations.Test;
import Lead_ProjectSpecificMethods.ProjectSpecificMethod;

public class DuplicateLead extends ProjectSpecificMethod {

	@Test
	public void duplicateLead() throws InterruptedException {


		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		//Find leads
		driver.findElementByLinkText("Find Leads").click();

		//Select Firstname
		//driver.findElementByXPath("(//div//input[@name='firstName'])[3]").sendKeys("Sakthi");
		//driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();

		//Select Email
		driver.findElementByXPath("(//span[contains(@class,'x-tab-strip-text ')])[3]").click();
		driver.findElementByXPath("//input[contains(@name,'emailAddress')]").sendKeys("xyz@gmail.com");
		driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();

		Thread.sleep(3000);

		//Select first result
		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();

		Thread.sleep(2000);
		driver.findElementById("center-content-column").isDisplayed();

		//Click Duplicate lead
		driver.findElementByLinkText("Duplicate Lead").click();
		String leadTitle=driver.findElementById("sectionHeaderTitle_leads").getText();
		System.out.println(leadTitle);

		driver.findElementByName("submitButton").click();


		String str=driver.findElementById("viewLead_firstName_sp").getText();
		if(str.equals("Sakthi"))
		{
			System.out.println("Same name remains");
			//driver.close();
		}
		else
		{
			System.out.println("Name updated");
		}



	}

}
