package week5.day2.classroom;

import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LearnExcel {

	public static void main(String[] args) throws IOException {

		//Access excel
		XSSFWorkbook wbook=new XSSFWorkbook("./data/createleadData.xlsx");

		//Get first sheet
		XSSFSheet wsheet = wbook.getSheetAt(0);

		//No of sheets
		System.out.println("No of sheets");
		System.out.println("--------------");
		System.out.println(wbook.getNumberOfSheets());

		//Get index of active sheet
		System.out.println("Index of active sheets");
		System.out.println(wbook.getActiveSheetIndex());

		//Get number of rows available
		int rowCount = wsheet.getLastRowNum();
		//System.out.println(rowCount);

		//Get number of columns available for zero th row
		short colCount = wsheet.getRow(0).getLastCellNum();

		//Loop through rows and columns
		for (int i = 1; i <=rowCount; i++) {

			XSSFRow row = wsheet.getRow(i);

			for (int j = 0; j <colCount ; j++) {

				XSSFCell cell = row.getCell(j);
				
				DataFormatter df = new DataFormatter();
				String formatCellValue = df.formatCellValue(cell);
				//System.out.println(colCount);
				System.out.println(cell.getStringCellValue());
				//cell.getStringCellValue()*/
			}
		}

	}

}
