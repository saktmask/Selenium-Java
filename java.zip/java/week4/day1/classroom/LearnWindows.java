package week4.day1.classroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class LearnWindows {

	public static void main(String[] args) throws InterruptedException {
		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");
		
		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();
		
		// Maximize the browser
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//URL
		driver.get("http://leafground.com/pages/Window.html");
		Thread.sleep(2000);
		
		driver.findElementByXPath("//button[.='Open Multiple Windows']").click();
		
		Set<String> windowHandles=driver.getWindowHandles();
		System.out.println(windowHandles.size());
		List<String> lstwindowHandles=new ArrayList<String>(windowHandles);
		String str = lstwindowHandles.get(windowHandles.size()-1);
		
		//String str = lstwindowHandles.get(1);
		
		driver.switchTo().window(str);
		String title = driver.getTitle();
		System.out.println(title);
		driver.quit();
		
	}

}
