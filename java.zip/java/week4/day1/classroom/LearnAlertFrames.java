package week4.day1.classroom;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.runtime.Timeout;

public class LearnAlertFrames {

	public static void main(String[] args) throws InterruptedException {

		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");

		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();

		// Maximize the browser
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//URL
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		Thread.sleep(2000);

		driver.switchTo().frame("iframeResult");
		driver.findElementByXPath("//button[.='Try it']").click();

		Alert a=driver.switchTo().alert();
		a.sendKeys("Sakthi");
		a.accept();

		String str=driver.findElementByXPath("//p[@id='demo']").getText();
		System.out.println(str);

		if(str.contains("Hello Sakthi! How are you today?"))
		{
			System.out.println("Successfully validated");
			driver.close();
		}
		else
		{
			System.out.println("Name not found");
		}

	}

}
