package week4.assignment;

import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CreateLead {

	public static void main(String[] args) {

		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");

		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();

		// Maximize the browser
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//URL
		driver.get("http://leaftaps.com/opentaps/control/main");

		// Enter the UserName
		driver.findElementById("username").sendKeys("DemoSalesManager");

		// Enter the Password
		driver.findElementById("password").sendKeys("crmsfa");

		// Click on Login Button
		driver.findElementByClassName("decorativeSubmit").click();

		// Click on crm/sfa button
		driver.findElementByLinkText("CRM/SFA").click();

		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		// Click on Create Lead button
		driver.findElementByLinkText("Create Lead").click();

		// Enter Company Name
		driver.findElementById("createLeadForm_companyName").sendKeys("HCL");

		// Enter First Name
		driver.findElementById("createLeadForm_firstName").sendKeys("Sakthi");

		// Enter Last Name
		driver.findElementById("createLeadForm_lastName").sendKeys("M");

		// Enter First Name Local
		driver.findElementById("createLeadForm_firstNameLocal").sendKeys("Sakthi");

		// Enter Last Name Local
		driver.findElementById("createLeadForm_lastNameLocal").sendKeys("M");

		//Salutation
		driver.findElementById("createLeadForm_personalTitle").sendKeys("Mr");

		//Date of Birth
		driver.findElementById("createLeadForm_birthDate").sendKeys("12/19/2019");

		// Select 'Source' as 'Other' (Handling DropDown)
		Select dd_Source= new Select(driver.findElementById("createLeadForm_dataSourceId"));
		dd_Source.selectByVisibleText("Other");

		//Title
		driver.findElementById("createLeadForm_generalProfTitle").sendKeys("Tit");

		//Annual Revenue
		driver.findElementById("createLeadForm_annualRevenue").sendKeys("10");

		// Select 'Industry' as 'Computer-Hardware'
		Select dd_Industry=new Select(driver.findElementById("createLeadForm_industryEnumId"));
		dd_Industry.selectByIndex(2);

		// Select 'Ownership' as Last
		Select dd_Owner=new Select(driver.findElementById("createLeadForm_ownershipEnumId"));
		List<WebElement> l_Options=dd_Owner.getOptions();
		int len=l_Options.size();
		dd_Owner.selectByIndex(len-1);

		//SIC Code
		driver.findElementById("createLeadForm_sicCode").sendKeys("1234");

		//Description
		driver.findElementById("createLeadForm_description").sendKeys("DEsc");

		//Important Note
		driver.findElementById("createLeadForm_importantNote").sendKeys("Important Note");

		//Country code
		driver.findElementById("createLeadForm_primaryPhoneCountryCode").sendKeys("91");

		//Area code
		driver.findElementById("createLeadForm_primaryPhoneAreaCode").sendKeys("600100");

		//Extension
		driver.findElementById("createLeadForm_primaryPhoneExtension").sendKeys("321247");

		//Department
		driver.findElementById("createLeadForm_departmentName").sendKeys("Software");

		// Select 'Preferred Currency' as 'INR'
		Select dd_Currency= new Select(driver.findElementById("createLeadForm_currencyUomId"));
		dd_Currency.selectByValue("INR");

		//No of Employees
		driver.findElementById("createLeadForm_numberEmployees").sendKeys("100");

		//Ticker symbol
		driver.findElementById("createLeadForm_tickerSymbol").sendKeys("Yes");	

		//Person to ask for
		driver.findElementById("createLeadForm_primaryPhoneAskForName").sendKeys("Sathish");

		//Web URL
		driver.findElementById("createLeadForm_primaryWebUrl").sendKeys("www.url.com");

		//To Name
		driver.findElementById("createLeadForm_generalToName").sendKeys("Sathish");

		//Address Line 1&2
		driver.findElementById("createLeadForm_generalAddress1").sendKeys("ABC");
		driver.findElementById("createLeadForm_generalAddress2").sendKeys("DEF");

		//City
		driver.findElementById("createLeadForm_generalCity").sendKeys("Chennai");

		//Country
		WebElement webElementCountry = driver.findElementById("createLeadForm_generalCountryGeoId");
		Select s1=new Select(webElementCountry);
		s1.selectByVisibleText("India");

		//State or province
		WebElement webElementProvince = driver.findElementById("createLeadForm_generalStateProvinceGeoId");
		Select s=new Select(webElementProvince);
		s.selectByVisibleText("TAMILNADU");

		//Postal code
		driver.findElementById("createLeadForm_generalPostalCode").sendKeys("600100");

		//Postal extension code
		driver.findElementById("createLeadForm_generalPostalCodeExt").sendKeys("6666");

		//Select 'Marketting campaign' as Last before
		Select dd_Market=new Select(driver.findElementById("createLeadForm_marketingCampaignId"));
		List<WebElement> l_Market=dd_Market.getOptions();
		int len1=l_Market.size();
		dd_Market.selectByIndex(len1-2);

		//Phone number
		driver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys("9876543210");

		//Email address
		driver.findElementById("createLeadForm_primaryEmail").sendKeys("xyz@gmail.com");

		// Click on Create Lead (Submit) button
		driver.findElementByClassName("smallSubmit").click();

		// Verify the Lead is created by checking the Company or First Name
		String str=driver.findElementById("viewLead_firstName_sp").getText();

		//Verify Currency name
		String str1=driver.findElementById("viewLead_currencyUomId_sp").getText();
		if(str.contains("Sakthi")&&str1.contains("INR - Indian Rupee"))
		{
			System.out.println("Name verified");
			System.out.println("Currency selection verified");
			driver.close();
		}


	}

}
