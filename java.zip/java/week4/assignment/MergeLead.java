package week4.assignment;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MergeLead {

	public static void main(String[] args) throws InterruptedException {


		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");

		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();

		// Maximize the browser
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//URL
		driver.get("http://leaftaps.com/opentaps/control/main");

		// Enter the UserName
		driver.findElementById("username").sendKeys("DemoSalesManager");

		// Enter the Password
		driver.findElementById("password").sendKeys("crmsfa");

		// Click on Login Button
		driver.findElementByClassName("decorativeSubmit").click();
		Thread.sleep(2000);

		// Click on crm/sfa button
		driver.findElementByLinkText("CRM/SFA").click();


		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		//Merge Leads
		driver.findElementByLinkText("Merge Leads").click();

		//Click Image of From Lead
		driver.findElementByXPath("(//img[contains(@src,'/images/fieldlookup.gif')])[1]").click();

		//Switch to new window
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> listHandle=new ArrayList<>(windowHandles);
		String str=listHandle.get(1);
		driver.switchTo().window(str);

		//Find Lead ID
		driver.findElementByName("id").sendKeys("10273");

		//Find leads
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();

		Thread.sleep(2000);

		//Select first result
		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();

		//Close the current window
		//driver.close();

		//Switch the control to parent window
		str=listHandle.get(0);
		driver.switchTo().window(str);

		Thread.sleep(2000);

		//Click Image of To Lead
		driver.findElementByXPath("(//img[contains(@src,'/images/fieldlookup.gif')])[2]").click();

		//Switch to new window
		Set<String> windowHandles1 = driver.getWindowHandles();
		List<String> listHandle1=new ArrayList<>(windowHandles1);
		String str1=listHandle1.get(1);
		driver.switchTo().window(str1);

		//Find Lead ID
		driver.findElementByName("id").sendKeys("10274");

		//Find leads
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();

		Thread.sleep(2000);

		//Select first result
		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();

		//Close the current window
		//driver.close();

		//Switch the control to parent window
		str1=listHandle1.get(0);
		driver.switchTo().window(str1);

		//Click on Merge button
		driver.findElementByXPath("//a[contains(@class,'buttonDangerous')]").click();
		Thread.sleep(2000);

		//Alert
		Alert a =driver.switchTo().alert();
		a.accept();

		//Find leads
		driver.findElementByLinkText("Find Leads").click();

		//Find Lead ID
		driver.findElementByName("id").sendKeys("10273");

		//Find leads
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();

		Thread.sleep(3000);
		WebElement recordInfo=driver.findElementByXPath("//div[@class='x-paging-info']");
		String result=recordInfo.getText();

		if(result.equals("No records to display"))
		{
			System.out.println("Records deleted");
			driver.close();
		}
		else
		{
			System.out.println("No records deleted");
		}

	}

}
