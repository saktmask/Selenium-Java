package week4.assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DuplicateLead {

	public static void main(String[] args) throws InterruptedException {


		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1.exe");

		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();

		// Maximize the browser
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//URL
		driver.get("http://leaftaps.com/opentaps/control/main");

		// Enter the UserName
		driver.findElementById("username").sendKeys("DemoSalesManager");

		// Enter the Password
		driver.findElementById("password").sendKeys("crmsfa");

		// Click on Login Button
		driver.findElementByClassName("decorativeSubmit").click();
		Thread.sleep(2000);

		// Click on crm/sfa button
		driver.findElementByLinkText("CRM/SFA").click();


		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		//Find leads
		driver.findElementByLinkText("Find Leads").click();

		//Select Firstname
		//driver.findElementByXPath("(//div//input[@name='firstName'])[3]").sendKeys("Sakthi");
		//driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();

		//Select Email
		driver.findElementByXPath("(//span[contains(@class,'x-tab-strip-text ')])[3]").click();
		driver.findElementByXPath("//input[contains(@name,'emailAddress')]").sendKeys("xyz@gmail.com");
		driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();

		Thread.sleep(2000);

		//Select first result
		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();

		Thread.sleep(2000);
		driver.findElementById("center-content-column").isDisplayed();

		//Click Duplicate lead
		driver.findElementByLinkText("Duplicate Lead").click();
		String leadTitle=driver.findElementById("sectionHeaderTitle_leads").getText();
		System.out.println(leadTitle);

		driver.findElementByName("submitButton").click();


		String str=driver.findElementById("viewLead_firstName_sp").getText();
		if(str.equals("Sakthi"))
		{
			System.out.println("Same name remains");
			driver.close();
		}
		else
		{
			System.out.println("Name updated");
		}



	}

}
