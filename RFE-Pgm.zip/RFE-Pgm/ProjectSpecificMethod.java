package ProjectSpecificMethods;


import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class ProjectSpecificMethod {
	public ChromeDriver driver;
	public String excelFileName;


	@BeforeMethod
	@Parameters({"url","uname","pwd"})
	public void login(String url, String uName, String passWord) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElementById("username").sendKeys(uName);
		driver.findElementById("password").sendKeys(passWord);
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();

	}

	@AfterMethod
	public void logout() {
		driver.close();
	}
	
	@DataProvider
	public String[][] getData() throws IOException
	{
		/*String[][] data=new String[2][3];
		data[0][0]="ABC";
		data[0][1]="Sathish";
		data[0][2]="M";
		
		data[1][0]="DEF";
		data[1][1]="Sakt";
		data[1][2]="Mask";
		return data;*/
		
		ReadDataExcel rd=new ReadDataExcel();
		return rd.readData(excelFileName);
	}

}
