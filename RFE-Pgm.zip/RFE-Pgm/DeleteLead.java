package week4.project;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import ProjectSpecificMethods.ProjectSpecificMethod;

public class DeleteLead extends ProjectSpecificMethod {

	@BeforeClass
	public void setName()
	{
		excelFileName="deleteLeadData";
	}
	
	@Test(dataProvider="getData")
	public void deleteLead(String mobileNo) throws InterruptedException {
		
		// Click on Leads
		driver.findElementByLinkText("Leads").click();

		//Find leads
		driver.findElementByLinkText("Find Leads").click();
		Thread.sleep(2000);

		driver.findElementByXPath("//*[@class='x-tab-strip-text ' and text()='Phone']").click();
		Thread.sleep(2000);

		WebElement phoneCode=driver.findElementByXPath("//*[@name='phoneCountryCode']");
		phoneCode.clear();
		phoneCode.sendKeys("91");
		driver.findElementByName("phoneNumber").sendKeys(mobileNo);

		driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();

		Thread.sleep(2000);
		WebElement leadID=driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]");
		String strLead=leadID.getText();
		leadID.click();

		Thread.sleep(2000);
		driver.findElementById("center-content-column").isDisplayed();

		driver.findElementByClassName("subMenuButtonDangerous").click();

		//Find leads
		driver.findElementByLinkText("Find Leads").click();
		Thread.sleep(2000);

		driver.findElementByXPath("//*[@name='id']").sendKeys(strLead);
		driver.findElementByXPath("(//*[text()='Find Leads'])[3]").click();
		Thread.sleep(3000);
		WebElement recordInfo=driver.findElementByXPath("//div[@class='x-paging-info']");
		String result=recordInfo.getText();

		if(result.equals("No records to display"))
		{
			System.out.println("Records deleted");
			//driver.close();
		}
		else
		{
			System.out.println("No records deleted");
		}
	}

}
