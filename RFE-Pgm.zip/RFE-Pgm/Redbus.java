package week4.project;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Redbus {

	public static void main(String[] args) throws InterruptedException {
		// Set the property for ChromeDriver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver1");

		// Initiate the ChromeBroswer
		ChromeDriver driver=new ChromeDriver();

		//URL
		driver.get("https://www.redbus.in/");

		// Maximize the browser
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(3000);
		
		WebElement srcElement = driver.findElementById("src");
		srcElement.sendKeys("Chennai (All Locations)");
		Thread.sleep(2000);
		srcElement.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		
		WebElement destElement = driver.findElementById("dest");
		destElement.sendKeys("Salem (All Locations)");
		Thread.sleep(2000);
		destElement.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		
		driver.findElementByXPath("//div[@class='fl search-box date-box gtm-onwardCalendar']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@id='rb-calendar_onward_cal']//table//*//td[@class='current day']").click();
		Thread.sleep(2000);
			
		driver.findElementByXPath("//div[@class='fl search-box date-box gtm-returnCalendar']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@id='rb-calendar_return_cal']//table//*//td[@class='current day']").click();
		Thread.sleep(2000);
		
		driver.findElementById("search_btn").click();
	
		Thread.sleep(3000);
		driver.findElementByXPath("//ul//li//label[contains(@for,'dtAfter 6 pm')][1]").click();
		
		List<BusSeats> busList=new ArrayList<BusSeats>();
		List<WebElement> busName = driver.findElementsByXPath("//div[@class='travels lh-24 f-bold d-color']");
		List<WebElement> busPrice = driver.findElementsByXPath("//span[@class='f-19 f-bold']");
		List<WebElement> busSeats = driver.findElementsByXPath("//div[@class='button view-seats fr']");
		
		int len=busName.size();
		
		for(int i=0;i<=len;i++)
		{
			busList.add(new BusSeats(busName.get(i),Integer.parseInt(busPrice.get(i).getText().replaceAll("\\D", "")),busSeats.get(i)));
		}
		Collections.sort(busList);
		System.out.println(busList);
		
		/*List<String> busString=new ArrayList<>();
		List<String> busPriceString=new ArrayList<>();
		List<String> busSeatsString=new ArrayList<>();*/
		
		/*for (WebElement element : busList) {
			busString.add(element.getText());
		}
		for (WebElement element : busPrice) {
			busPriceString.add(element.getText());
		}
		for (WebElement element : busSeats) {
			busSeatsString.add(element.getText());
		}*/
		
		
		/*for (String string : busString) {
			System.out.println(string);
		}
		*/
		
		
	}

}
class BusSeats implements Comparable<BusSeats>
{
	WebElement bus;
	private int price;
	WebElement seats;
	
	BusSeats(WebElement bus, int price, WebElement seats)
	{
		this.bus=bus;
		this.price=price;
		this.seats=seats;
	}
	
	public String toString()
	{
		return "BusSeats [bus=" + bus + ", price=" + price + "]";
	}
	
	public int compareTo(BusSeats bs)
	{
		if(this.price<bs.price) {
		return -1;
		}
		else return 1;
		
	}
	
	
}
