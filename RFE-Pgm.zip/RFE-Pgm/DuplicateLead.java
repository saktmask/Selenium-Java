package week4.project;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import ProjectSpecificMethods.ProjectSpecificMethod;

public class DuplicateLead extends ProjectSpecificMethod {
	@BeforeClass
	public void setName()
	{
		excelFileName="duplicateLeadData";
	}

	@Test(dataProvider="getData")
	public void duplicateLead(String mobileNo, String eMail) throws InterruptedException
	{
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		driver.findElementByXPath("//span[text()='Phone']").click();
		driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys(mobileNo);

		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(2000);
		//Select first result
		driver.findElementByXPath("//div[@class='x-grid3-body']//tr[1]//td//a[1]").click();
		Thread.sleep(2000);
		driver.findElementByLinkText("Duplicate Lead").click();
		driver.findElementById("createLeadForm_primaryEmail").sendKeys(eMail);
		driver.findElementByName("submitButton").click();
	}

}
